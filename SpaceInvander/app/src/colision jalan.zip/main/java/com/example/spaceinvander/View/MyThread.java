package com.example.spaceinvander.View;

import android.os.AsyncTask;

import com.example.spaceinvander.Model.Meteor;

import java.util.Random;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

public class MyThread {
//    protected MainActivity ma;
//    protected Meteor meteor;
//
//    public MyThread(MainActivity ma,Meteor meteor){
//        this.ma = ma;
//        this.meteor = meteor;
//    }
//
//    @Override
//    protected Meteor doInBackground(Meteor... meteors) {
//        while(this.meteor.getmY()<=this.meteor.getBatas()){
//            int kecepatan = this.meteor.randomAngka();
//            this.meteor.setKecepatan(kecepatan);
//
//            try {
//                Thread.sleep(1000);
//            } catch (InterruptedException e) {
//                e.printStackTrace();
//            }
//        }
//        this.publishProgress();
//        return this.meteor;
//    }
//
//    protected void onProgressUpdate(){
//        this.meteor.setmX();
//        this.meteor.setmY();
//    }
//
//    protected void onPostExecute(Meteor.. meteors){
//
//    }
}
