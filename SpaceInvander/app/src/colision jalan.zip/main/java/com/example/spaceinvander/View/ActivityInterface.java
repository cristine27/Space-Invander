package com.example.spaceinvander.View;

public interface ActivityInterface {
    void changePage(int i);
    static final int mainMenu = 1;
    static final int game = 2;
    static final int highScore = 3;
}
