package com.example.spaceinvander.View;

public interface GameInterface {
    void setWidth(int w);
    void setHeight(int h);
}
